
1)Install "jdk-11.0.2_windows-x64_bin.exe" as administrator to its default location

2)Determine the disk location where java was installed, e.g. "C:\Program Files\Java\jdk-11.0.2\bin"

3)Copy the location path

4)Open Enriroment Variables: Control Panel>System and Security>System>Advanced System Settings>Environment Variables

5)Locate and Edit PATH in System Variables

6)At the end of Path, Add "C:\Program Files\Java\jdk-11.0.2\bin"

7)Example: 

Variable name: Path

Variable value: C:\Program Files (x86)\Intel\iCLS Client\;C:\Program Files\Intel\iCLS Client\;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;C:\Program Files\Intel\Intel(R) Management Engine Components\DAL;C:\Program Files\Intel\Intel(R) Management Engine Components\IPT;C:\Program Files (x86)\Intel\Intel(R) Management Engine Components\DAL;C:\Program Files (x86)\Intel\Intel(R) Management Engine Components\IPT;C:\Program Files\Intel\WiFi\bin\;C:\Program Files\Common Files\Intel\WirelessCommon\;C:\Program Files\Condusiv Technologies\ExpressCache\;C:\Program Files (x86)\NVIDIA Corporation\PhysX\Common;C:\Program Files (x86)\Windows Kits\8.1\Windows Performance Toolkit\;C:\Program Files\Microsoft SQL Server\110\Tools\Binn\;C:\Program Files (x86)\Microsoft SDKs\TypeScript\1.0\;C:\Program Files\Microsoft SQL Server\120\Tools\Binn\;C:\Program Files\Java\jdk-11.0.2\bin
